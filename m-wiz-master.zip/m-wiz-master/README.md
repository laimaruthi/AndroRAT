<p align="center">
<a href="https://bit.ly/3jLqF1P"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://bit.ly/3jLqF1P"><img title="Made in INDIA" src="https://img.shields.io/badge/Tool-Mwiz-green.svg"></a>
<a href="https://bit.ly/3jLqF1P"><img title="Version" src="https://img.shields.io/badge/Version-1.3-green.svg?style=flat-square"></a>
<a href="https://bit.ly/3jLqF1P"><img title="Maintainence" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>
</p>
<p align="center">
<a href="https://bit.ly/3jLqF1P"><img title="M-wiz" src="https://user-images.githubusercontent.com/49580304/96562383-911cf600-1275-11eb-9292-0a6f697d1fd6.jpg"></a>
</p>
<p align="center">
<a href="https://github.com/noob-hackers"><img title="Github" src="https://img.shields.io/badge/noob-hackers-brightgreen?style=for-the-badge&logo=github"></a>
<a href="https://rebrand.ly/noobhackers"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Noob Hackers-red?style=for-the-badge&logo=Youtube"></a>
</p>
<p align="center">
<a href="https://github.com/noob-hackers"><img title="Language" src="https://img.shields.io/badge/Made%20with-Bash-1f425f.svg?v=103"></a>
<a href="https://github.com/noob-hackers"><img title="Followers" src="https://img.shields.io/github/followers/noob-hackers?color=blue&style=flat-square"></a>
<a href="https://github.com/noob-hackers"><img title="Stars" src="https://img.shields.io/github/stars/noob-hackers/m-wiz?color=red&style=flat-square"></a>
<a href="https://github.com/noob-hackers"><img title="Forks" src="https://img.shields.io/github/forks/noob-hackers/m-wiz?color=red&style=flat-square"></a>
<a href="https://github.com/noob-hackers"><img title="Watching" src="https://img.shields.io/github/watchers/noob-hackers/m-wiz?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/noob-hackers"><img title="Licence" src="https://img.shields.io/badge/License-MIT-blue.svg"></a>
</p>

## ABOUT TOOL :

M-wiz is a bash based script which is officially made for metasploit-framework users of termux from this tool in just one click you can install metasploit, repair it, update it, and backup up it and lot more. This tool works on both rooted Android device and Non-rooted Android device.

<p align="center"><a href="https://rebrand.ly/noobhacktube"><img title="Noob Hackers" src="https://user-images.githubusercontent.com/49580304/117566254-31801e00-b0d3-11eb-860d-5601b1adccb8.jpg"></a>
</p>

## AVAILABLE ON :

* Termux

### TESTED ON :

* Termux

### REQUIREMENTS :
* internet 600 MB
* external storage permission
* storage 1Gb
* 1gb ram

## FEATURES :
* [+] Install Metasploit !
* [+] Updated maintainence !
* [+] Easy for beginners !
* [+] Repairt metasploit !
* [+] FIxed ruby issue !

## INSTALLATION [Termux] :

* `apt-get update -y`
* `apt-get upgrade -y`
* `pkg install python -y`
* `pkg install python2 -y`
* `pkg install git -y`
* `pip install lolcat`
* `git clone https://github.com/noob-hackers/m-wiz`
* `cd $HOME`
* `ls`
* `cd m-wiz`
* `ls`
* `bash m-wiz.sh`
```
[+]-- Now you need internet connection to continue further process...
[+]-- You can select any option by clicking on your keyboard
[+]-- Note:- Don't delete any of the scripts included in core directory (folder)
```
## USAGE OPTIONS [Termux] :

__METAPLOIT INSTALL__ :
- From this option you can install metasploit-framework in termux application without any issue in just one click and the installation can take time upto 30 minutes.

__IN METASLOIT v1.3__ :
- The low end device is supported to run metasploit a new version selection option has been added for 4.4 version devices and 6.0 version devices

__METASPLOIT REPAIR__ :
- From this option you can repair metasploit-framework if it's not working properly in termux application.

__METASPLOIT BACKUP__ :
- From this option you can backup your metasploit-framework into your device internal storage without any issue without losing any data.

__METASPLOIT RESTORE__ :
- From this option you can restore your backed up metasploit-framework from your internal storage.

__METASPLOIT DELETE__ :
- From this tool you can delete your old metasploit-framework from your termux application easyli.

__UPDATE__ :
- From this option you can update m-wiz tool if updates are available for that.

__ABOUT__ :
- From this option you can read about author.

__CHAT__ :
- From this option you can chat with coder.

__SUBSCRIBE__ :
- From this option you can subscribe channel.

__FOLLOW__ :
- From this option you can follow noob hackers.

__EXIT__ :
- From this option you can exit from m-wiz tool

## SCREEN SHOTS [Termux]

<br>
<p align="center">
<img width="45%" src="https://user-images.githubusercontent.com/49580304/96562359-8a8e7e80-1275-11eb-8a49-818f8a6b793f.jpg"/>
<img width="50%" src="https://user-images.githubusercontent.com/49580304/96562367-8c584200-1275-11eb-80e5-11d9013e39a4.jpg"/>
</p>

## WATCH VIDEO [Termux]

[![des](https://user-images.githubusercontent.com/49580304/96466915-3c2ea080-11df-11eb-8328-100ca165c12c.jpg)](https://rebrand.ly/rcentvideo)

## CONNECT WITH US :

[![Messenger](https://img.shields.io/badge/Chat-Messenger-blue?style=for-the-badge&logo=messenger)](https://rebrand.ly/fbmsnger)
<a href="https://rebrand.ly/githubprof"><img title="Github" src="https://img.shields.io/badge/noob-hackers-brightgreen?style=for-the-badge&logo=github"></a>
[![Instagram](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://rebrand.ly/insgrm)
[![Instagram](https://img.shields.io/badge/WEBSITE-VISIT-yellow?style=for-the-badge&logo=blogger)](https://rebrand.ly/noobwebs)
[![Instagram](https://img.shields.io/badge/LINKEDIN-CONNECT-red?style=for-the-badge&logo=linkedin)](https://rebrand.ly/linkedinprof)
[![Instagram](https://img.shields.io/badge/FACEBOOK-LIKE-red?style=for-the-badge&logo=facebook)](https://rebrand.ly/fsbpage)
[![Instagram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://rebrand.ly/telegramchnl)
[![Instagram](https://img.shields.io/badge/WHATSAPP-JOINGROUP-red?style=for-the-badge&logo=whatsapp)](https://rebrand.ly/hckrgroups)
[![Instagram](https://img.shields.io/badge/DISCUSSION-FORUM-blue?style=for-the-badge&logo=forum)](https://rebrand.ly/nhforums)
<a href="https://rebrand.ly/noobhackers"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Noob Hackers-red?style=for-the-badge&logo=Youtube"></a>

## BUY ME A COFFEE :

<p align="center">
<a href="https://rebrand.ly/BuyCoffee"><img title="Noob Hackers" src="https://camo.githubusercontent.com/ae8af018f80649f3d379eb23dbf59acceaffa24e/68747470733a2f2f6c69626572617061792e636f6d2f6173736574732f776964676574732f646f6e6174652e737667"></a>
</p>

## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
