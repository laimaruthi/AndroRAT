#colour section
red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
#script coding starts
clear
echo "  "
echo -e '$grn                          
                        _ _          
                       //\/\etasploit $rset'
echo " "
echo -e "$red                MeTaSpLoIt Is InStALlInG...$rset"
echo "  "
echo -e "$grn        [ThIs MaY TaKe TiMe UpTo 30 MiNuTeS sO wAiT]$rset"
echo " "
sleep 3.0
clear
echo -e "$red                         ChEcKiNg..>"
sleep 2.0
clear
echo -e "$red                         ChEcKiNg...>"
sleep 2.0
clear
echo -e "$red                         ChEcKiNg....>"
sleep 2.0
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo " "
cd $HOME
cd m-wiz/core/min
bash opti.sh